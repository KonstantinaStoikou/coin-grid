#define ITERDP
	
int pureRecursive(int **, int, int, int, int);
int matrRecursive(int **, int **, int, int, int, int);
int iterativeDP(int **, int **, int, int);
void pathfinder(int **, int**, int, int, int, int);

